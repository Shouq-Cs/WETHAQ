const express = require("express");
const cors = require("cors");
const path = require("path");
const fs = require("fs");
require("dotenv").config();

const OpenAI = require("openai");

const app = express();
const PORT = 5000;
const DATABASE_PATH = path.join(__dirname, "wethaq-database.json");

app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));

function createEmptyDatabase() {
  return {
    users: [],
    complaints: [],
    nextUserId: 1,
    nextComplaintId: 1,
  };
}

function readDatabase() {
  if (!fs.existsSync(DATABASE_PATH)) {
    writeDatabase(createEmptyDatabase());
  }

  const rawData = fs.readFileSync(DATABASE_PATH, "utf8");
  return JSON.parse(rawData || JSON.stringify(createEmptyDatabase()));
}

function writeDatabase(data) {
  fs.writeFileSync(DATABASE_PATH, JSON.stringify(data, null, 2));
}

function getTodayDate() {
  return new Date().toLocaleDateString();
}

const client = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

app.get("/api/test", (req, res) => {
  res.json({ message: "Backend database is working!" });
});

// Register user and save account in the backend database
app.post("/api/register", (req, res) => {
  try {
    const { name, email, password, role } = req.body;

    if (!name || !email || !password || !role) {
      return res.status(400).json({ error: "All fields are required." });
    }

    if (!email.includes("@")) {
      return res.status(400).json({ error: "Please enter a valid university email." });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: "Password must be at least 6 characters." });
    }

    if (!["student", "staff", "admin"].includes(role)) {
      return res.status(400).json({ error: "Invalid role." });
    }

    const database = readDatabase();

    const emailExists = database.users.some(function (user) {
      return user.email.toLowerCase() === email.toLowerCase();
    });

    if (emailExists) {
      return res.status(409).json({ error: "An account with this email already exists." });
    }

    const newUser = {
      id: database.nextUserId++,
      name,
      email,
      password,
      role,
      createdAt: new Date().toISOString(),
    };

    database.users.push(newUser);
    writeDatabase(database);

    res.status(201).json({
      message: "Account created successfully.",
      user: removePassword(newUser),
    });
  } catch (error) {
    console.error("Register error:", error.message);
    res.status(500).json({ error: "Failed to create account." });
  }
});

// Login user from the backend database
app.post("/api/login", (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: "Email and password are required." });
    }

    const database = readDatabase();

    const user = database.users.find(function (storedUser) {
      return storedUser.email.toLowerCase() === email.toLowerCase() && storedUser.password === password;
    });

    if (!user) {
      return res.status(401).json({ error: "Invalid email or password." });
    }

    res.json({ message: "Login successful.", user: removePassword(user) });
  } catch (error) {
    console.error("Login error:", error.message);
    res.status(500).json({ error: "Failed to log in." });
  }
});

function removePassword(user) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
  };
}

// Save complaint in the backend database
app.post("/api/complaints", (req, res) => {
  try {
    const {
      userEmail,
      title,
      description,
      category,
      urgency,
      department,
      manualReviewRequired,
      suggestions,
      attachmentName,
    } = req.body;

    if (!userEmail || !title || !description) {
      return res.status(400).json({ error: "User email, title, and description are required." });
    }

    const database = readDatabase();

    const newComplaint = {
      id: database.nextComplaintId++,
      userEmail,
      title,
      description,
      category: category || "Default Category",
      urgency: urgency || "Non-Urgent",
      department: department || "Manual Review",
      status: "Under Review",
      response: "",
      manualReviewRequired: Boolean(manualReviewRequired),
      suggestions: suggestions || [],
      attachmentName: attachmentName || "",
      date: getTodayDate(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    database.complaints.push(newComplaint);
    writeDatabase(database);

    res.status(201).json(newComplaint);
  } catch (error) {
    console.error("Save complaint error:", error.message);
    res.status(500).json({ error: "Failed to save complaint." });
  }
});

// Read complaints. Students see their own complaints. Staff/Admin read all complaints.
app.get("/api/complaints", (req, res) => {
  try {
    const { userEmail, role } = req.query;
    const database = readDatabase();

    let complaints = database.complaints;

    if (role === "student" && userEmail) {
      complaints = complaints.filter(function (complaint) {
        return complaint.userEmail.toLowerCase() === userEmail.toLowerCase();
      });
    }

    complaints = complaints.slice().sort(function (a, b) {
      return b.id - a.id;
    });

    res.json(complaints);
  } catch (error) {
    console.error("Read complaints error:", error.message);
    res.status(500).json({ error: "Failed to read complaints." });
  }
});

app.get("/api/complaints/:id", (req, res) => {
  try {
    const database = readDatabase();
    const complaint = database.complaints.find(function (storedComplaint) {
      return storedComplaint.id === Number(req.params.id);
    });

    if (!complaint) {
      return res.status(404).json({ error: "Complaint not found." });
    }

    res.json(complaint);
  } catch (error) {
    console.error("Read complaint error:", error.message);
    res.status(500).json({ error: "Failed to read complaint." });
  }
});

// Staff updates complaint status and response, then the update is saved in the backend database
app.put("/api/complaints/:id", (req, res) => {
  try {
    const { status, response } = req.body;
    const allowedStatuses = ["Under Review", "In Progress", "Resolved"];

    if (status && !allowedStatuses.includes(status)) {
      return res.status(400).json({ error: "Invalid complaint status." });
    }

    const database = readDatabase();
    const complaint = database.complaints.find(function (storedComplaint) {
      return storedComplaint.id === Number(req.params.id);
    });

    if (!complaint) {
      return res.status(404).json({ error: "Complaint not found." });
    }

    complaint.status = status || complaint.status;
    complaint.response = response ?? complaint.response;
    complaint.updatedAt = new Date().toISOString();

    writeDatabase(database);

    res.json(complaint);
  } catch (error) {
    console.error("Update complaint error:", error.message);
    res.status(500).json({ error: "Failed to update complaint." });
  }
});

// Delete only complaints that are still Under Review
app.delete("/api/complaints/:id", (req, res) => {
  try {
    const database = readDatabase();
    const complaint = database.complaints.find(function (storedComplaint) {
      return storedComplaint.id === Number(req.params.id);
    });

    if (!complaint) {
      return res.status(404).json({ error: "Complaint not found." });
    }

    if (complaint.status !== "Under Review") {
      return res.status(400).json({ error: "Only Under Review complaints can be deleted." });
    }

    database.complaints = database.complaints.filter(function (storedComplaint) {
      return storedComplaint.id !== Number(req.params.id);
    });

    writeDatabase(database);

    res.json({ message: "Complaint deleted successfully." });
  } catch (error) {
    console.error("Delete complaint error:", error.message);
    res.status(500).json({ error: "Failed to delete complaint." });
  }
});

// AI rewrite route
app.post("/chat", async (req, res) => {
  try {
    const { description } = req.body;

    if (!description || description.trim() === "") {
      return res.status(400).json({ error: "Complaint description is required." });
    }

    if (!client) {
      return res.json({
        rewrittenText:
          "I would like to formally report the following issue: " +
          description +
          " I kindly request that the responsible department reviews this complaint and takes the necessary action as soon as possible.",
      });
    }

    const response = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content:
            "Rewrite university complaints professionally, clearly, and politely. Keep the original meaning. Do not add new facts. Only return the rewritten complaint.",
        },
        { role: "user", content: description },
      ],
    });

    res.json({ rewrittenText: response.choices[0].message.content });
  } catch (error) {
    console.error("OPENAI ERROR:", error.message);
    res.status(500).json({ error: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
  console.log(`Backend database file: ${DATABASE_PATH}`);
});
