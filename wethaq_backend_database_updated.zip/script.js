const API_BASE_URL = "http://localhost:5000";

function getCurrentUser() {
  return {
    email: sessionStorage.getItem("wethaqUserEmail"),
    name: sessionStorage.getItem("wethaqUserName"),
    role: sessionStorage.getItem("wethaqUserRole"),
  };
}

function saveCurrentUser(user) {
  sessionStorage.setItem("wethaqUserEmail", user.email);
  sessionStorage.setItem("wethaqUserName", user.name);
  sessionStorage.setItem("wethaqUserRole", user.role);
}

function showError(elementId, message) {
  const element = document.getElementById(elementId);
  if (element) element.textContent = message;
}

function clearErrors(ids) {
  ids.forEach(function (id) {
    showError(id, "");
  });
}

async function login(event) {
  event.preventDefault();

  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();

  clearErrors(["emailError", "passwordError"]);

  let isValid = true;

  if (email === "") {
    showError("emailError", "University email is required.");
    isValid = false;
  } else if (!email.includes("@")) {
    showError("emailError", "Please enter a valid university email.");
    isValid = false;
  }

  if (password === "") {
    showError("passwordError", "Password is required.");
    isValid = false;
  } else if (password.length < 6) {
    showError("passwordError", "Password must be at least 6 characters.");
    isValid = false;
  }

  if (!isValid) return;

  try {
    const response = await fetch(`${API_BASE_URL}/api/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });

    const data = await response.json();

    if (!response.ok) {
      showError("emailError", data.error || "Invalid email or password.");
      return;
    }

    saveCurrentUser(data.user);

    if (data.user.role === "student") {
      window.location.href = "dashboard.html";
    } else if (data.user.role === "staff") {
      window.location.href = "staff.html";
    } else if (data.user.role === "admin") {
      window.location.href = "admin.html";
    }
  } catch (error) {
    showError("emailError", "Cannot connect to backend server.");
  }
}

async function createAccount(event) {
  event.preventDefault();

  const name = document.getElementById("fullName").value.trim();
  const email = document.getElementById("registerEmail").value.trim();
  const role = document.getElementById("registerRole").value;
  const password = document.getElementById("registerPassword").value.trim();
  const confirmPassword = document.getElementById("confirmPassword").value.trim();

  clearErrors([
    "nameError",
    "registerEmailError",
    "roleError",
    "registerPasswordError",
    "confirmPasswordError",
  ]);

  let isValid = true;

  if (name === "") {
    showError("nameError", "Full name is required.");
    isValid = false;
  }

  if (email === "") {
    showError("registerEmailError", "University email is required.");
    isValid = false;
  } else if (!email.includes("@")) {
    showError("registerEmailError", "Please enter a valid university email.");
    isValid = false;
  }

  if (role === "") {
    showError("roleError", "Please select your role.");
    isValid = false;
  }

  if (password === "") {
    showError("registerPasswordError", "Password is required.");
    isValid = false;
  } else if (password.length < 6) {
    showError("registerPasswordError", "Password must be at least 6 characters.");
    isValid = false;
  }

  if (confirmPassword === "") {
    showError("confirmPasswordError", "Please confirm your password.");
    isValid = false;
  } else if (password !== confirmPassword) {
    showError("confirmPasswordError", "Passwords do not match.");
    isValid = false;
  }

  if (!isValid) return;

  try {
    const response = await fetch(`${API_BASE_URL}/api/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, password, role }),
    });

    const data = await response.json();

    if (!response.ok) {
      showError("registerEmailError", data.error || "Failed to create account.");
      return;
    }

    document.getElementById("accountModal").classList.remove("hidden");
  } catch (error) {
    showError("registerEmailError", "Cannot connect to backend server.");
  }
}

function togglePassword() {
  const passwordInput = document.getElementById("password");
  const showButton = document.querySelector(".show-btn");

  if (!passwordInput || !showButton) return;

  if (passwordInput.type === "password") {
    passwordInput.type = "text";
    showButton.textContent = "Hide";
  } else {
    passwordInput.type = "password";
    showButton.textContent = "Show";
  }
}

function goToSubmit() {
  window.location.href = "submit.html";
}

function goToHistory() {
  window.location.href = "history.html";
}

function goToDashboard() {
  window.location.href = "dashboard.html";
}

function goToLogin() {
  window.location.href = "index.html";
}

function logout() {
  sessionStorage.clear();
  window.location.href = "index.html";
}

async function fetchComplaints() {
  const user = getCurrentUser();
  const params = new URLSearchParams();

  if (user.email) params.append("userEmail", user.email);
  if (user.role) params.append("role", user.role);

  const response = await fetch(`${API_BASE_URL}/api/complaints?${params.toString()}`);
  if (!response.ok) throw new Error("Failed to load complaints.");
  return await response.json();
}

async function loadDashboardOverview() {
  const totalElement = document.getElementById("totalComplaints");
  const inProgressElement = document.getElementById("inProgressComplaints");
  const resolvedElement = document.getElementById("resolvedComplaints");

  if (!totalElement && !inProgressElement && !resolvedElement) return;

  try {
    const complaints = await fetchComplaints();

    const total = complaints.length;
    const inProgress = complaints.filter(function (complaint) {
      return complaint.status === "In Progress";
    }).length;
    const resolved = complaints.filter(function (complaint) {
      return complaint.status === "Resolved";
    }).length;

    if (totalElement) totalElement.textContent = total;
    if (inProgressElement) inProgressElement.textContent = inProgress;
    if (resolvedElement) resolvedElement.textContent = resolved;
  } catch (error) {
    if (totalElement) totalElement.textContent = "-";
  }
}

async function rewriteComplaint() {
  const description = document.getElementById("complaintDescription");
  const aiSuggestionBox = document.getElementById("aiSuggestionBox");

  if (!description || !aiSuggestionBox) return;

  const text = description.value.trim();

  if (text === "") {
    alert("Please write a complaint description first.");
    return;
  }

  aiSuggestionBox.classList.remove("empty-state");
  aiSuggestionBox.textContent = "Rewriting complaint...";

  try {
    const response = await fetch(`${API_BASE_URL}/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ description: text }),
    });

    const data = await response.json();
    aiSuggestionBox.textContent = data.rewrittenText || "No rewritten complaint returned.";
  } catch (error) {
    aiSuggestionBox.textContent =
      "I would like to formally report the following issue: " +
      text +
      " I kindly request that the responsible department reviews this complaint and takes the necessary action as soon as possible.";
  }
}

function useRewrittenText() {
  const description = document.getElementById("complaintDescription");
  const aiSuggestionBox = document.getElementById("aiSuggestionBox");

  if (!description || !aiSuggestionBox) return;

  const rewrittenText = aiSuggestionBox.textContent.trim();

  if (rewrittenText === "" || rewrittenText === "No rewritten complaint yet.") {
    alert("Please generate a rewritten complaint first.");
    return;
  }

  description.value = rewrittenText;
}

function classifyComplaint(description) {
  const text = description.toLowerCase();

  let category = "Default Category";
  let department = "Manual Review";
  let manualReviewRequired = true;

  if (
    text.includes("ac") ||
    text.includes("air conditioner") ||
    text.includes("elevator") ||
    text.includes("building") ||
    text.includes("classroom") ||
    text.includes("lab")
  ) {
    category = "Facilities";
    department = "Facilities Department";
    manualReviewRequired = false;
  } else if (
    text.includes("grade") ||
    text.includes("course") ||
    text.includes("professor") ||
    text.includes("exam") ||
    text.includes("assignment")
  ) {
    category = "Academic";
    department = "Academic Affairs Department";
    manualReviewRequired = false;
  } else if (
    text.includes("payment") ||
    text.includes("tuition") ||
    text.includes("refund") ||
    text.includes("fee")
  ) {
    category = "Financial";
    department = "Finance Department";
    manualReviewRequired = false;
  } else if (
    text.includes("login") ||
    text.includes("wifi") ||
    text.includes("wi-fi") ||
    text.includes("system") ||
    text.includes("portal")
  ) {
    category = "Technical";
    department = "IT Department";
    manualReviewRequired = false;
  } else if (
    text.includes("registration") ||
    text.includes("schedule") ||
    text.includes("certificate")
  ) {
    category = "Administrative";
    department = "Administration Department";
    manualReviewRequired = false;
  }

  let urgency = "Non-Urgent";

  if (
    text.includes("dangerous") ||
    text.includes("fire") ||
    text.includes("emergency") ||
    text.includes("electrical") ||
    text.includes("safety")
  ) {
    urgency = "Very Urgent";
  } else if (
    text.includes("urgent") ||
    text.includes("unsafe") ||
    text.includes("immediately")
  ) {
    urgency = "Urgent";
  }

  const suggestions = manualReviewRequired
    ? ["No suggestions available"]
    : [
        "Attach a supporting document or image if available.",
        "Provide the exact location, course, or related details.",
        "Track the complaint status from Complaint History.",
      ];

  return {
    category,
    department,
    urgency,
    manualReviewRequired,
    suggestions,
  };
}

async function submitComplaint(event) {
  event.preventDefault();

  const user = getCurrentUser();
  if (!user.email) {
    alert("Please log in before submitting a complaint.");
    window.location.href = "index.html";
    return;
  }

  const title = document.getElementById("complaintTitle").value.trim();
  const description = document.getElementById("complaintDescription").value.trim();
  const attachmentInput = document.getElementById("attachment");

  clearErrors(["titleError", "descriptionError"]);

  let isValid = true;

  if (title === "") {
    showError("titleError", "Complaint title is required.");
    isValid = false;
  }

  if (description === "") {
    showError("descriptionError", "Complaint description is required.");
    isValid = false;
  }

  if (!isValid) return;

  const aiResult = classifyComplaint(description);
  const attachmentName = attachmentInput && attachmentInput.files.length > 0
    ? attachmentInput.files[0].name
    : "";

  try {
    const response = await fetch(`${API_BASE_URL}/api/complaints`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        userEmail: user.email,
        title,
        description,
        category: aiResult.category,
        urgency: aiResult.urgency,
        department: aiResult.department,
        manualReviewRequired: aiResult.manualReviewRequired,
        suggestions: aiResult.suggestions,
        attachmentName,
      }),
    });

    const complaint = await response.json();

    if (!response.ok) {
      alert(complaint.error || "Failed to save complaint.");
      return;
    }

    showSubmittedComplaintResult(complaint);

    document.getElementById("complaintTitle").value = "";
    document.getElementById("complaintDescription").value = "";
    if (attachmentInput) attachmentInput.value = "";
  } catch (error) {
    alert("Cannot connect to backend server.");
  }
}

function showSubmittedComplaintResult(complaint) {
  const resultCard = document.getElementById("resultCard");
  if (resultCard) resultCard.classList.remove("hidden");

  const fields = {
    resultCategory: complaint.category,
    resultUrgency: complaint.urgency,
    resultDepartment: complaint.department,
    resultStatus: complaint.status,
    modalCategory: complaint.category,
    modalStatus: complaint.status,
  };

  Object.keys(fields).forEach(function (id) {
    const element = document.getElementById(id);
    if (element) element.textContent = fields[id];
  });

  const suggestionsList = document.getElementById("suggestionsList");
  if (suggestionsList) {
    suggestionsList.innerHTML = "";
    complaint.suggestions.forEach(function (suggestion) {
      const li = document.createElement("li");
      li.textContent = suggestion;
      suggestionsList.appendChild(li);
    });
  }

  const successModal = document.getElementById("successModal");
  if (successModal) successModal.classList.remove("hidden");

  if (resultCard) {
    resultCard.scrollIntoView({ behavior: "smooth", block: "start" });
  }
}

function getStatusClass(status) {
  if (status === "In Progress") return "status-in-progress";
  if (status === "Resolved") return "status-resolved";
  return "status-under-review";
}

async function loadComplaintHistory() {
  const historyList = document.getElementById("historyList");
  const statusFilter = document.getElementById("statusFilter");

  if (!historyList) return;

  try {
    const complaints = await fetchComplaints();
    const selectedStatus = statusFilter ? statusFilter.value : "All";

    const filteredComplaints = selectedStatus === "All"
      ? complaints
      : complaints.filter(function (complaint) {
          return complaint.status === selectedStatus;
        });

    updateHistorySummary(complaints);

    if (filteredComplaints.length === 0) {
      historyList.innerHTML = `
        <div class="empty-history">
          <h3>No complaints found</h3>
          <p>Your submitted complaints will appear here after submission.</p>
        </div>
      `;
      return;
    }

    historyList.innerHTML = "";

    filteredComplaints.forEach(function (complaint) {
      historyList.appendChild(createComplaintCard(complaint, false));
    });
  } catch (error) {
    historyList.innerHTML = `
      <div class="empty-history">
        <h3>Backend connection error</h3>
        <p>Please make sure the server is running.</p>
      </div>
    `;
  }
}

function createComplaintCard(complaint, editable) {
  const responseText = complaint.response && complaint.response.trim() !== ""
    ? complaint.response
    : "No department response yet.";

  const card = document.createElement("div");
  card.className = "complaint-card";

  card.innerHTML = `
    <div class="complaint-card-header">
      <div>
        <h3>${escapeHTML(complaint.title)}</h3>
        <p class="complaint-date">Submitted on ${complaint.date} by ${escapeHTML(complaint.userEmail || "")}</p>
      </div>

      <span class="status-badge ${getStatusClass(complaint.status)}">
        ${complaint.status}
      </span>
    </div>

    <div class="complaint-meta">
      <div class="meta-item">
        <span>Category</span>
        <strong>${escapeHTML(complaint.category)}</strong>
      </div>

      <div class="meta-item">
        <span>Urgency</span>
        <strong>${escapeHTML(complaint.urgency)}</strong>
      </div>

      <div class="meta-item">
        <span>Department</span>
        <strong>${escapeHTML(complaint.department)}</strong>
      </div>
    </div>

    <p class="complaint-description">${escapeHTML(complaint.description)}</p>

    <div class="complaint-response">
      <strong>Department Response:</strong>
      <p>${escapeHTML(responseText)}</p>
    </div>
  `;

  if (editable) {
    const editBox = document.createElement("div");
    editBox.className = "complaint-response";
    editBox.innerHTML = `
      <strong>Update Complaint</strong>
      <div class="input-group" style="margin-top:12px;">
        <label>Status</label>
        <select id="status-${complaint.id}">
          <option value="Under Review" ${complaint.status === "Under Review" ? "selected" : ""}>Under Review</option>
          <option value="In Progress" ${complaint.status === "In Progress" ? "selected" : ""}>In Progress</option>
          <option value="Resolved" ${complaint.status === "Resolved" ? "selected" : ""}>Resolved</option>
        </select>
      </div>
      <div class="input-group">
        <label>Response</label>
        <textarea id="response-${complaint.id}" placeholder="Write department response...">${escapeHTML(complaint.response || "")}</textarea>
      </div>
      <button class="primary-btn" onclick="updateComplaintFromStaff(${complaint.id})">Save Update</button>
    `;
    card.appendChild(editBox);
  }

  return card;
}

function escapeHTML(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function updateHistorySummary(complaints) {
  const totalElement = document.getElementById("historyTotal");
  const inProgressElement = document.getElementById("historyInProgress");
  const resolvedElement = document.getElementById("historyResolved");

  const total = complaints.length;
  const inProgress = complaints.filter(function (complaint) {
    return complaint.status === "In Progress";
  }).length;
  const resolved = complaints.filter(function (complaint) {
    return complaint.status === "Resolved";
  }).length;

  if (totalElement) totalElement.textContent = total;
  if (inProgressElement) inProgressElement.textContent = inProgress;
  if (resolvedElement) resolvedElement.textContent = resolved;
}

async function loadStaffComplaints() {
  const staffList = document.getElementById("staffComplaintList");
  if (!staffList) return;

  try {
    const response = await fetch(`${API_BASE_URL}/api/complaints?role=staff`);
    const complaints = await response.json();

    updateStaffSummary(complaints);

    if (complaints.length === 0) {
      staffList.innerHTML = `
        <div class="empty-history">
          <h3>No complaints assigned yet</h3>
          <p>New complaints will appear here.</p>
        </div>
      `;
      return;
    }

    staffList.innerHTML = "";
    complaints.forEach(function (complaint) {
      staffList.appendChild(createComplaintCard(complaint, true));
    });
  } catch (error) {
    staffList.innerHTML = `
      <div class="empty-history">
        <h3>Backend connection error</h3>
        <p>Please make sure the server is running.</p>
      </div>
    `;
  }
}

function updateStaffSummary(complaints) {
  updateText("staffTotal", complaints.length);
  updateText("staffInProgress", complaints.filter(c => c.status === "In Progress").length);
  updateText("staffResolved", complaints.filter(c => c.status === "Resolved").length);
}

function updateText(id, value) {
  const element = document.getElementById(id);
  if (element) element.textContent = value;
}

async function updateComplaintFromStaff(id) {
  const status = document.getElementById(`status-${id}`).value;
  const response = document.getElementById(`response-${id}`).value.trim();

  try {
    const result = await fetch(`${API_BASE_URL}/api/complaints/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status, response }),
    });

    const data = await result.json();

    if (!result.ok) {
      alert(data.error || "Failed to update complaint.");
      return;
    }

    alert("Complaint updated and saved successfully.");
    loadStaffComplaints();
  } catch (error) {
    alert("Cannot connect to backend server.");
  }
}

async function loadAdminReports() {
  const reportList = document.getElementById("adminReportList");
  if (!reportList) return;

  try {
    const response = await fetch(`${API_BASE_URL}/api/complaints?role=admin`);
    const complaints = await response.json();

    updateText("adminTotal", complaints.length);
    updateText("adminInProgress", complaints.filter(c => c.status === "In Progress").length);
    updateText("adminResolved", complaints.filter(c => c.status === "Resolved").length);

    const byCategory = countBy(complaints, "category");
    const byDepartment = countBy(complaints, "department");

    reportList.innerHTML = `
      <div class="complaint-card">
        <h3>Complaints by Category</h3>
        ${createReportRows(byCategory)}
      </div>
      <div class="complaint-card">
        <h3>Complaints by Department</h3>
        ${createReportRows(byDepartment)}
      </div>
    `;
  } catch (error) {
    reportList.innerHTML = `
      <div class="empty-history">
        <h3>Backend connection error</h3>
        <p>Please make sure the server is running.</p>
      </div>
    `;
  }
}

function countBy(items, key) {
  return items.reduce(function (result, item) {
    const value = item[key] || "Unknown";
    result[value] = (result[value] || 0) + 1;
    return result;
  }, {});
}

function createReportRows(data) {
  const entries = Object.entries(data);
  if (entries.length === 0) return "<p>No data available.</p>";

  return entries
    .map(function ([label, count]) {
      return `
        <div class="status-row" style="color:#365c37; border-bottom:1px solid #dcebd7;">
          <span>${escapeHTML(label)}</span>
          <strong>${count}</strong>
        </div>
      `;
    })
    .join("");
}

window.addEventListener("DOMContentLoaded", function () {
  const user = getCurrentUser();

  const userEmailText = document.getElementById("userEmailText");
  const welcomeName = document.getElementById("welcomeName");
  const navUserName = document.getElementById("navUserName");

  if (userEmailText && user.email) userEmailText.textContent = user.email;
  if (welcomeName && user.name) welcomeName.textContent = "Welcome back, " + user.name;
  if (navUserName && user.name) navUserName.textContent = user.name;

  loadDashboardOverview();
  loadComplaintHistory();
  loadStaffComplaints();
  loadAdminReports();
});
