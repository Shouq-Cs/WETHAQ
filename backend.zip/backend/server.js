const express = require("express");
const cors = require("cors");
const path = require("path");
require("dotenv").config();

const OpenAI = require("openai");

const app = express();

app.use(cors());
app.use(express.json());

// يخلي السيرفر يقرأ ملفات الواجهة الموجودة خارج مجلد backend
app.use(express.static(path.join(__dirname, "..")));

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Test route
app.get("/api/test", (req, res) => {
  res.json({ message: "Backend is working!" });
});

// AI rewrite route
app.post("/chat", async (req, res) => {
  try {
    const { description } = req.body;

    if (!description || description.trim() === "") {
      return res.status(400).json({
        error: "Complaint description is required.",
      });
    }

    const response = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content:
            "Rewrite university complaints professionally, clearly, and politely. Keep the original meaning. Do not add new facts. Only return the rewritten complaint.",
        },
        {
          role: "user",
          content: description,
        },
      ],
    });

    const rewrittenText = response.choices[0].message.content;

    res.json({
      rewrittenText: rewrittenText,
    });
  } catch (error) {
    console.error("OPENAI ERROR MESSAGE:", error.message);
    console.error("OPENAI ERROR STATUS:", error.status);
    console.error("OPENAI ERROR CODE:", error.code);

    res.status(500).json({
      error: error.message,
    });
  }
});

// Start server
const PORT = 5000;

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});